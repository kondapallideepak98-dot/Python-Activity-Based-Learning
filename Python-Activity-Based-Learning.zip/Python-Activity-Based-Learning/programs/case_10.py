"""Campus Event Financial Planning - illustrative classroom assumptions."""

venue, equipment, transport = 10000, 6000, 4000
catering_per_person, certificate_per_person = 120, 30
fee, sponsorship, expected = 250, 12000, 150
fixed_cost = venue + equipment + transport
variable_cost = catering_per_person + certificate_per_person
total_cost = fixed_cost + variable_cost * expected
registration_income = fee * expected
shortfall = max(total_cost - registration_income - sponsorship, 0)
contribution = fee - variable_cost
minimum = 0
if contribution > 0:
    while sponsorship + contribution * minimum < fixed_cost:
        minimum += 1
    print("Minimum break-even registrations:", minimum)
else:
    print("Break-even impossible with current fee")
print("Estimated cost: Rs", total_cost)
print("Registration income: Rs", registration_income)
print("Sponsorship shortfall: Rs", shortfall)
