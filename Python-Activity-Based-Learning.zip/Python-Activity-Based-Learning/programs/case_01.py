"""University Scholarship Allocation - illustrative classroom assumptions."""

students = [
    {"name":"Asha", "marks":[85, 79, 90], "attendance":92, "income":180000},
    {"name":"Bala", "marks":[88, 76, 90], "attendance":90, "income":160000},
    {"name":"Charan", "marks":[92, 35, 95], "attendance":94, "income":120000},
    {"name":"Divya", "marks":[80, 82, 92], "attendance":92, "income":150000}
]
eligible = []
for student in students:
    average = sum(student["marks"]) / len(student["marks"])
    if min(student["marks"]) >= 40 and average >= 70 and student["attendance"] >= 75 and student["income"] <= 300000:
        student["average"] = average
        eligible.append(student)
eligible.sort(key=lambda s: (-s["average"], -s["attendance"], s["income"], s["name"]))
print("SCHOLARSHIP RANKING")
for rank, student in enumerate(eligible, 1):
    print(rank, student["name"], "Average:", round(student["average"], 2))
print("Eligible:", len(eligible), "of", len(students))
