"""Hospital Billing and Patient Classification - illustrative classroom assumptions."""

patients = [
    ("Ravi", 35, False, 500, 1200, 2500),
    ("Meena", 67, False, 500, 1800, 3200),
    ("John", 42, True, 400, 800, 1500)
]
for name, age, low_income, consultation, diagnostics, treatment in patients:
    charges = [consultation, diagnostics, treatment]
    if min(charges) < 0:
        print(name, "Invalid charges")
        continue
    gross = sum(charges)
    discount = 0.20 if age >= 60 else (0.10 if low_income else 0)
    payable = gross * (1 - discount)
    category = "Subsidized" if discount > 0 else "Standard"
    print(name, category, "Payable: Rs", round(payable, 2))
