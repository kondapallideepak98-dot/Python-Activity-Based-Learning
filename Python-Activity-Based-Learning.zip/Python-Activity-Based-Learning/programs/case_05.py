"""Multi-Plan Telecommunications Cost Optimization - illustrative classroom assumptions."""

plans = [
    ("Basic", 199, 15, 300, 28),
    ("Smart", 299, 25, 500, 28),
    ("Plus", 399, 40, 1000, 30)
]
data_used, calls_used, days_needed, budget = 25, 450, 28, 500
choices = []
for name, price, data, calls, validity in plans:
    if validity < days_needed:
        continue
    total = price + max(data_used - data, 0) * 15 + max(calls_used - calls, 0) * 1
    print(name, "Total: Rs", total)
    if total <= budget:
        choices.append((total, name))
if choices:
    best = min(choices)
    print("Best eligible plan:", best[1], "Rs", best[0])
else:
    print("No plan meets the budget")
