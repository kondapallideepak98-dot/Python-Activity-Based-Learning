"""Railway Fare and Reservation Calculator - illustrative classroom assumptions."""

passengers = [("Ravi", 32, "Sleeper"), ("Lakshmi", 65, "AC")]
distance = 350
base = min(distance, 100) * 1
base += min(max(distance - 100, 0), 200) * 0.8
base += max(distance - 300, 0) * 0.6
grand_total = 0
for name, age, travel_class in passengers:
    multiplier = 2.5 if travel_class == "AC" else 1.5
    fare = base * multiplier
    if age >= 60:
        fare *= 0.80
    fare += 30
    grand_total += fare
    print(name, travel_class, "Fare: Rs", round(fare, 2))
print("Total fare: Rs", round(grand_total, 2))
print("Cancellation penalty: Rs", round(grand_total * 0.15, 2))
