"""Manufacturing Cost and Profitability Analysis - illustrative classroom assumptions."""

quantity = 100
material_per_unit = 200
labour_per_unit = 80
wastage_rate = 0.05
machine_cost = 4000
selling_price = 380
target_margin = 0.15
material = quantity * material_per_unit
labour = quantity * labour_per_unit
wastage = material * wastage_rate
cost = material + labour + wastage + machine_cost
revenue = quantity * selling_price
profit = revenue - cost
margin = profit / revenue if revenue > 0 else 0
print("Cost: Rs", cost, "Revenue: Rs", revenue)
print("Profit: Rs", profit, "Margin:", round(margin * 100, 2), "%")
print("Target achieved:", margin >= target_margin)
