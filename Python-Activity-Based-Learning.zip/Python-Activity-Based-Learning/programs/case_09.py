"""Multi-Currency Travel Budget Analysis - illustrative classroom assumptions."""

rates = {"USD":84, "EUR":92, "INR":1}
expenses = [("Flights", 250, "USD"), ("Hotel", 180, "EUR"), ("Food", 6000, "INR"), ("Transport", 45, "USD")]
budget = 50000
totals = {}
for category, amount, currency in expenses:
    converted = amount * rates[currency]
    if currency != "INR":
        converted *= 1.02
    totals[category] = totals.get(category, 0) + converted
    print(category, "Rs", round(converted, 2))
total = sum(totals.values())
print("Total: Rs", round(total, 2), "Within budget:", total <= budget)
print("Largest category:", max(totals, key=totals.get))
