"""Progressive Electricity Billing - illustrative classroom assumptions."""

units_by_month = {"Jan":90, "Feb":170, "Mar":360, "Apr":200}
previous = None
for month, units in units_by_month.items():
    charge = min(units, 100) * 2
    charge += min(max(units - 100, 0), 100) * 3
    charge += max(units - 200, 0) * 5
    total = charge + 50
    if units > 300:
        total *= 1.05
    if units <= 100:
        total *= 0.95
    warning = previous is not None and total > previous * 1.30
    print(month, "Units:", units, "Bill: Rs", round(total, 2), "Unusual rise:", warning)
    previous = total
