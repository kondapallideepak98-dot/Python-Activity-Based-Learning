"""Employee Payroll and Deduction Analysis - illustrative classroom assumptions."""

employees = [("Anita", 25000, 8, 3000), ("Vikram", 40000, 12, 5000)]
for name, basic, overtime_hours, incentive in employees:
    hra = basic * 0.20
    da = basic * 0.10
    overtime = overtime_hours * 200
    gross = basic + hra + da + overtime + incentive
    deduction = min(max(gross - 20000, 0), 20000) * 0.05
    deduction += max(gross - 40000, 0) * 0.10
    net = gross - deduction
    print("EMPLOYEE:", name)
    print("Gross: Rs", round(gross, 2), "Deduction: Rs", round(deduction, 2), "Net: Rs", round(net, 2))
