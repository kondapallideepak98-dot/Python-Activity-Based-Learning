"""Retail Billing with Multiple Discount Rules - illustrative classroom assumptions."""

items = [("Rice", "grocery", 2, 600), ("Headphones", "electronics", 1, 2200), ("Notebook", "stationery", 3, 100)]
taxes = {"grocery":0.05, "electronics":0.18, "stationery":0.12}
subtotal = sum(quantity * price for name, category, quantity, price in items)
discount = min(subtotal * 0.10, 500) if subtotal >= 3000 else 0
total_tax = 0
for name, category, quantity, price in items:
    line_amount = quantity * price
    line_discount = discount * line_amount / subtotal
    tax = (line_amount - line_discount) * taxes[category]
    total_tax += tax
    print(name, "Amount:", line_amount, "Tax:", round(tax, 2))
print("Subtotal:", subtotal, "Discount:", round(discount, 2))
print("Tax:", round(total_tax, 2), "Final: Rs", round(subtotal - discount + total_tax, 2))
